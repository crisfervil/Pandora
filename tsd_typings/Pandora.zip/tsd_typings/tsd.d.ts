/// <reference path="angular2/angular2.d.ts" />
/// <reference path="angular2/router.d.ts" />
/// <reference path="es6-promise/es6-promise.d.ts" />
/// <reference path="rx/rx-lite.d.ts" />
/// <reference path="rx/rx.d.ts" />
/// <reference path="jquery/jquery.d.ts" />
/// <reference path="chartjs/chart.d.ts" />
