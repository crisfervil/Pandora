import {Component, View} from 'angular2/angular2';
import {RouterLink} from 'angular2/router';


@Component({
    selector: 'account'
})
@View({
    templateUrl: './components/entities/account/account.html?v=<%= VERSION %>',
    directives: [RouterLink]
})
export class Account {


}
