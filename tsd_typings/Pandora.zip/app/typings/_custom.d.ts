/*
 * Our custom types
 */
/// <reference path="systemjs.d.ts" />


/*
 * tsd generated types
 */
/// <reference path="../../tsd_typings/tsd.d.ts" />